export const LIST_ALL_TODOS = 'LIST_ALL_TODOS';
export const ADD_TODOS = 'ADD_TODOS';
export const DONE_TODOS = 'DONE_TODOS';
export const DELETE_TODO = 'DELETE_TODO';
export const LIST_ALL_ALREADY_DONES = 'LIST_ALL_ALREADY_DONES';
export const MAKE_ALL_DONE = 'MAKE_ALL_DONE';
export const SEARCH = 'SEARCH';

